<?php
add_action( 'wp_enqueue_scripts', 'manual__child_enqueue_styles' );
function manual__child_enqueue_styles() {
    wp_enqueue_style( 'manual-style', get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'manual-child-style', get_stylesheet_uri() );
}

?>