</div>
</div>

<!-- SECTION FOOTER TOP-->
<?php 
manual_footer_controls(); 
//SECTION FOOTER -->
manual_footer_controls_lower();
// HOOK -->
wp_footer(); 
?>
</body></html>