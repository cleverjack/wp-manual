<a href="http://www.youtube.com/watch?v=umDr0mPuyQc" target="_blank">
    <?php _e('Sorry, WPCustom Category Image works only under Wordpress 3.5 or higher', 'wpcustom-category-image'); ?>
    <br>
    <?php echo __('And... PHP ', 'wpcustom-category-image') . $min_php_version; ?>
</a>