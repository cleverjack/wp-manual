<div class="updated">
    <p>
        <?php
            printf('<strong>WPCustom Category Image</strong> - <a href="https://goo.gl/zG18dh" target="_blank">%s</a>',
            __('If you like this plugin, then please leave us a good rating and review.', 'wpcustom-category-image'));
        ?>
    </p>
    <?php
        printf('<p><small>%s <a href="https://s.tuart.me" target="_blank">Eduardo Stuart</a></small></p>',
        __('Developed with &#9829; by', 'wpcustom-category-image'));
    ?>
</div>