<?php
/**
 * @author     Manual
 * @copyright  (c) Copyright by Manual
 * @link       https://wpsmartapps.com/
 * @package    Manual
 * @since      2.6
 */
 
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}

require MANUALSUPPORT_PLUGIN_DIR . '/admin/includes/function.php';
require MANUALSUPPORT_PLUGIN_DIR . '/admin/includes/admin_menu.php';
